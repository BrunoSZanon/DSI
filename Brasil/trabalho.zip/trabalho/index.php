<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Bicho Chique</title>
         <link href="css/default.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
    </head>
    <body>
          <form method="post" action="index.php">
         
         <div class="col-sm-4">
        <img src="img/caopng.png" alt="Desenho de um cachorro da raça golden"/>
         </div>
        <h2>Formulário de ordem de serviço Bicho Chique</h2>
    
        <h4>Nome do cliente:</h4>
        <input type="text" name="nome" placeholder="Digite o nome do cliente">
        
        <h4>Telefone:</h4>
        <input type="number" name="telefone" placeholder="Digite o telefone do cliente">
        
        <h4>Animal:</h4>
        <input type="text" name="nomea" placeholder="Digite o nome do animal">
        
        <h4>Serviços:</h4>
         <input type="checkbox" name="servico" value="Banho e Tosa">Banho e Tosa<br/>
         <input type="checkbox" name="servico" value="Corte de Unhas">Corte de Unhas<br/>
         <input type="checkbox" name="servico" value="Limpeza de Ouvidos">Limpeza de ouvidos<br/>
         <input type="checkbox" name="servico" value="Vacinacao">Vacinação
         
        <h4>Data:</h4>
        <input type="date" name="data" placeholder="dd/mm/aaaa">
        
        <h4>Obsercações:</h4>
        <input type="text" name="obs" placeholder="Digite quaisquer observações">
        
         <br/>
         <br/>
         <input class="btn btn-success" type="submit" value="Enviar Ordem de Serviço">
          <br/> <br/> <br/> <br/> <br/> <br/>
          </form>
  
         <?PHP
                        if ($_POST) {
                            //print_r($_POST);
                            @$nome = $_POST['nome'];
                            @$telefone = $_POST['telefone'];
                            @$nomea = $_POST['nomea'];
                            @$servicoList = $_POST['servico'];
                            @$data = $_POST['data'];
                            @$obs = $_POST['obs'];
                            
                            echo('<div class="dados">
                                <div class="panel panel-success">
                                    <div class="panel-heading">Dados informados</div>
                                    <div class="panel-body">
                                        <p>'.$nome.'</p>
                                        <p>'.$telefone.'</p>
                                        <p>'.$nomea.'</p>
                                        <p>'.$servicoList.'</p>
                                        <p>'.$data.'</p>
                                        <p>'.$obs.'</p>
                                         </div>
                                    </div>
                                  </div>');
                        }
                        ?>
    </body>
</html>
